let name = 'Generator';
let price = 1000;

console.log('Обрано Генератор, ціна за одиницю 1000 кредитів');

price = 2000;

console.log('Обрано Генератор, ціна за одиницю 2000 кредитів');