let credits = 23580;    
const price_per_tv = 3000;

let quantity = prompt('Скільки телевізорів ви хочете купити?');

if (quantity === null){
    console.log('Операцію скасовано!');
} else{
    const total_Price = quantity * price_per_tv;
    if (total_Price > credits){
        console.log('Недостатньо коштів на рахунку!');
    }
}