const total = 100;
const ordered = 50;

if (ordered > total){
    console.log("На складі недостатня кількість товару!");
} else{
    console.log("Замовлення оформлено")
}
