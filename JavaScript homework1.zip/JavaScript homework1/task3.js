const ADMIN_PASSWORD = 'sjvosijc';
let massage;

const password = prompt('Введіть пароль!');
if (password === null){
    massage = 'Операцію скасовано!';
} else if (password === ADMIN_PASSWORD){
    massage = 'Ласкаво просимо!';
} else{
    massage = 'Доступ заборонено, невірний пароль!';
}

alert(massage);